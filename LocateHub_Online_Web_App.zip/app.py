import os
import secrets
from datetime import datetime, timedelta, timezone
from functools import wraps

from flask import Flask, jsonify, redirect, render_template, request, session, url_for, abort
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import check_password_hash, generate_password_hash

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "change-this-development-secret")
database_url = os.environ.get("DATABASE_URL", "sqlite:///locatehub.db")
if database_url.startswith("postgres://"):
    database_url = database_url.replace("postgres://", "postgresql://", 1)
app.config["SQLALCHEMY_DATABASE_URI"] = database_url
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db = SQLAlchemy(app)

DASHBOARD_PASSWORD = os.environ.get("LOCATEHUB_PASSWORD", "ChangeMe-123!")
INVITE_HOURS = int(os.environ.get("INVITE_HOURS", "24"))


def utcnow():
    return datetime.now(timezone.utc)


class Invitation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    token = db.Column(db.String(80), unique=True, nullable=False, index=True)
    label = db.Column(db.String(100), nullable=False, default="Phone")
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow)
    expires_at = db.Column(db.DateTime(timezone=True), nullable=False)
    active = db.Column(db.Boolean, nullable=False, default=True)
    consented_at = db.Column(db.DateTime(timezone=True), nullable=True)
    sharing = db.Column(db.Boolean, nullable=False, default=False)
    last_lat = db.Column(db.Float, nullable=True)
    last_lng = db.Column(db.Float, nullable=True)
    last_accuracy = db.Column(db.Float, nullable=True)
    last_seen = db.Column(db.DateTime(timezone=True), nullable=True)
    history = db.relationship("LocationPoint", backref="invitation", lazy=True,
                               cascade="all, delete-orphan")


class LocationPoint(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    invitation_id = db.Column(db.Integer, db.ForeignKey("invitation.id"), nullable=False, index=True)
    lat = db.Column(db.Float, nullable=False)
    lng = db.Column(db.Float, nullable=False)
    accuracy = db.Column(db.Float, nullable=True)
    recorded_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow)


def dashboard_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get("dashboard_authenticated"):
            return redirect(url_for("login", next=request.path))
        return fn(*args, **kwargs)
    return wrapper


def as_iso(value):
    if not value:
        return None
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.isoformat()


@app.route("/")
def index():
    if session.get("dashboard_authenticated"):
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        password = request.form.get("password", "")
        # Supports a hashed password if LOCATEHUB_PASSWORD_HASH is configured.
        password_hash = os.environ.get("LOCATEHUB_PASSWORD_HASH")
        valid = check_password_hash(password_hash, password) if password_hash else secrets.compare_digest(password, DASHBOARD_PASSWORD)
        if valid:
            session.clear()
            session["dashboard_authenticated"] = True
            return redirect(url_for("dashboard"))
        error = "Incorrect password. Try again."
    return render_template("login.html", error=error)


@app.route("/logout", methods=["POST"])
@dashboard_required
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/dashboard")
@dashboard_required
def dashboard():
    invitations = Invitation.query.order_by(Invitation.created_at.desc()).all()
    return render_template("dashboard.html", invitations=invitations, invite_hours=INVITE_HOURS)


@app.route("/api/invitations", methods=["POST"])
@dashboard_required
def create_invitation():
    body = request.get_json(silent=True) or {}
    label = str(body.get("label", "Phone")).strip()[:100] or "Phone"
    token = secrets.token_urlsafe(24)
    invite = Invitation(
        token=token,
        label=label,
        created_at=utcnow(),
        expires_at=utcnow() + timedelta(hours=INVITE_HOURS),
        active=True,
    )
    db.session.add(invite)
    db.session.commit()
    return jsonify({"id": invite.id, "label": invite.label,
                    "url": url_for("share_page", token=token, _external=True),
                    "expires_at": as_iso(invite.expires_at)}), 201


@app.route("/api/invitations/<int:invite_id>/revoke", methods=["POST"])
@dashboard_required
def revoke_invitation(invite_id):
    invite = db.get_or_404(Invitation, invite_id)
    invite.active = False
    invite.sharing = False
    db.session.commit()
    return jsonify({"ok": True})


@app.route("/api/locations")
@dashboard_required
def locations():
    now = utcnow()
    results = []
    for invite in Invitation.query.order_by(Invitation.created_at.desc()).all():
        results.append({
            "id": invite.id,
            "label": invite.label,
            "active": invite.active and invite.expires_at > now,
            "sharing": invite.sharing and invite.active and invite.expires_at > now,
            "consented": invite.consented_at is not None,
            "lat": invite.last_lat,
            "lng": invite.last_lng,
            "accuracy": invite.last_accuracy,
            "last_seen": as_iso(invite.last_seen),
            "expires_at": as_iso(invite.expires_at),
            "share_url": url_for("share_page", token=invite.token, _external=True),
        })
    return jsonify(results)


@app.route("/api/locations/<int:invite_id>/history")
@dashboard_required
def location_history(invite_id):
    invite = db.get_or_404(Invitation, invite_id)
    points = (LocationPoint.query.filter_by(invitation_id=invite.id)
              .order_by(LocationPoint.recorded_at.desc()).limit(500).all())
    points.reverse()
    return jsonify([{"lat": p.lat, "lng": p.lng, "accuracy": p.accuracy,
                     "recorded_at": as_iso(p.recorded_at)} for p in points])


@app.route("/share/<token>")
def share_page(token):
    invite = Invitation.query.filter_by(token=token).first_or_404()
    expired = invite.expires_at <= utcnow()
    if not invite.active or expired:
        return render_template("share.html", invite=invite, unavailable=True)
    return render_template("share.html", invite=invite, unavailable=False)


@app.route("/api/share/<token>/status")
def share_status(token):
    invite = Invitation.query.filter_by(token=token).first_or_404()
    if not invite.active or invite.expires_at <= utcnow():
        return jsonify({"ok": False, "message": "This invitation has expired or been revoked."}), 410
    return jsonify({"ok": True, "sharing": invite.sharing})


@app.route("/api/share/<token>/start", methods=["POST"])
def start_sharing(token):
    invite = Invitation.query.filter_by(token=token).first_or_404()
    if not invite.active or invite.expires_at <= utcnow():
        return jsonify({"ok": False, "message": "This invitation has expired or been revoked."}), 410
    body = request.get_json(silent=True) or {}
    if body.get("consent") is not True:
        return jsonify({"ok": False, "message": "Consent is required before sharing."}), 400
    invite.consented_at = utcnow()
    invite.sharing = True
    db.session.commit()
    return jsonify({"ok": True})


@app.route("/api/share/<token>/location", methods=["POST"])
def receive_location(token):
    invite = Invitation.query.filter_by(token=token).first_or_404()
    if not invite.active or invite.expires_at <= utcnow():
        return jsonify({"ok": False, "message": "This invitation has expired or been revoked."}), 410
    if not invite.sharing or not invite.consented_at:
        return jsonify({"ok": False, "message": "Location sharing has not been started with consent."}), 403
    body = request.get_json(silent=True) or {}
    try:
        lat, lng = float(body["lat"]), float(body["lng"])
        accuracy = float(body.get("accuracy", 0))
        if not (-90 <= lat <= 90 and -180 <= lng <= 180):
            raise ValueError("Coordinates out of range")
        if not (0 <= accuracy <= 100000):
            raise ValueError("Accuracy out of range")
    except (KeyError, TypeError, ValueError):
        return jsonify({"ok": False, "message": "Invalid GPS coordinates."}), 400
    timestamp = utcnow()
    invite.last_lat, invite.last_lng = lat, lng
    invite.last_accuracy, invite.last_seen = accuracy, timestamp
    db.session.add(LocationPoint(invitation_id=invite.id, lat=lat, lng=lng,
                                 accuracy=accuracy, recorded_at=timestamp))
    db.session.commit()
    return jsonify({"ok": True})


@app.route("/api/share/<token>/stop", methods=["POST"])
def stop_sharing(token):
    invite = Invitation.query.filter_by(token=token).first_or_404()
    invite.sharing = False
    db.session.commit()
    return jsonify({"ok": True})


@app.route("/health")
def health():
    return jsonify({"status": "ok"})


with app.app_context():
    db.create_all()


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "5000")), debug=True)
