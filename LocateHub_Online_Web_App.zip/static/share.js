const $ = (id) => document.getElementById(id);
const token = window.LOCATEHUB_TOKEN;
let watchId = null;
let active = false;
let sending = false;
function status(message, kind="") {
  $("share-status").textContent = message;
  $("share-status").className = "message" + (kind ? ` ${kind}` : "");
}
function updateControls() {
  $("start-btn").classList.toggle("hidden", active);
  $("stop-btn").classList.toggle("hidden", !active);
  $("consent").disabled = active;
}
async function post(url, data={}) {
  const response = await fetch(url, {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(data)});
  const result = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(result.message || "Request failed.");
  return result;
}
function stopWatch() {
  if (watchId !== null && navigator.geolocation) navigator.geolocation.clearWatch(watchId);
  watchId = null;
}
async function stopSharing() {
  stopWatch();
  active = false;
  updateControls();
  try { await post(`/api/share/${encodeURIComponent(token)}/stop`); } catch (_) {}
  status("Location sharing stopped. No new GPS updates will be sent.", "success-text");
}
async function sendPosition(position) {
  if (!active || sending) return;
  sending = true;
  try {
    await post(`/api/share/${encodeURIComponent(token)}/location`, {
      lat: position.coords.latitude,
      lng: position.coords.longitude,
      accuracy: position.coords.accuracy
    });
    status(`Sharing is active. GPS accuracy: about ${Math.round(position.coords.accuracy)} metres. Last sent: ${new Date().toLocaleTimeString()}`, "success-text");
  } catch (e) {
    status(e.message + " Sharing has been stopped.", "error-text");
    await stopSharing();
  } finally { sending = false; }
}
function onPositionError(error) {
  const messages = {
    1: "Location permission was denied. Enable location permission in your browser settings to share.",
    2: "Your phone could not determine a location. Try moving outdoors and check Location Services.",
    3: "Getting a GPS position timed out. Keep the page open and try again."
  };
  status(messages[error.code] || "Unable to get your location.", "error-text");
}
$("consent").addEventListener("change", () => { $("start-btn").disabled = !$("consent").checked; });
$("start-btn").addEventListener("click", async () => {
  if (!$("consent").checked) return;
  if (!window.isSecureContext) {
    status("GPS sharing requires HTTPS. Open the hosted HTTPS link rather than a local file or plain HTTP page.", "error-text");
    return;
  }
  if (!navigator.geolocation) {
    status("This browser does not support GPS location sharing. Try a current version of Chrome or Safari.", "error-text");
    return;
  }
  $("start-btn").disabled = true;
  status("Starting sharing. Your browser will ask for location permission…");
  try {
    await post(`/api/share/${encodeURIComponent(token)}/start`, {consent:true});
    active = true;
    updateControls();
    watchId = navigator.geolocation.watchPosition(sendPosition, onPositionError, {
      enableHighAccuracy:true, maximumAge:5000, timeout:20000
    });
    status("Waiting for your phone's GPS position…");
  } catch (e) {
    active = false;
    updateControls();
    $("start-btn").disabled = !$("consent").checked;
    status(e.message, "error-text");
  }
});
$("stop-btn").addEventListener("click", stopSharing);
window.addEventListener("pagehide", () => {
  stopWatch();
  // A best-effort stop. The server still retains the last received location.
  try { navigator.sendBeacon(`/api/share/${encodeURIComponent(token)}/stop`, new Blob(["{}"], {type:"application/json"})); } catch (_) {}
});
